package com.dicoding.todoapp.utils

const val TASK_ID = "TASK_ID"
const val TASK_TITLE = "TASK_TITLE"
const val TASK_DESCRIPTION = "TASK_DESCRIPTION"
const val TASK_DUE_DATE = "TASK_DUE_DATE"
const val NOTIFICATION_CHANNEL_ID = "notify-task"
const val SWITCH_VALUE = "switch-value"
