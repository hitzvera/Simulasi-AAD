package com.dicoding.habitapp.utils

const val HABIT = "HABIT"
const val HABIT_ID = "HABIT_ID"
const val HABIT_TITLE = "HABIT_TITLE"
const val ID_ONETIMEREQUEST = 100
const val NOTIFICATION_CHANNEL_ID = "notify-channel"
const val NOTIFICATION_CHANNEL_NAME = "habit channel"
const val NOTIF_UNIQUE_WORK: String = "NOTIF_UNIQUE_WORK"

